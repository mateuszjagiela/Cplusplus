#ifndef ANIMOWANEASSETY_H
#define ANIMOWANEASSETY_H
#include <iostream>
#include <SFML/Window.hpp>
#include <SFML/Graphics.hpp>


class AnimowaneAssety : public sf::Sprite
{
public :
    int predkosc_x;
    int predkosc_y;

    void CiaglaAnimacja(const sf::Time &elapsed);

};


#endif // ANIMOWANEASSETY_H
#pragma once
