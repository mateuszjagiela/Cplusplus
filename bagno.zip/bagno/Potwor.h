#ifndef POTWOR_H
#define POTWOR_H
#include <iostream>
#include <SFML/Window.hpp>
#include <SFML/Graphics.hpp>
#include"AnimowaneAssety.h"

class Potwor : public AnimowaneAssety
{
public :
    Potwor(int a,int b,const sf::Texture &tex);

};


#endif // POTWOR_H
#pragma once
