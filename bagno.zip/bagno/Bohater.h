#ifndef BOHATER_H
#define BOHATER_H
#include <iostream>
#include <SFML/Window.hpp>
#include <SFML/Graphics.hpp>
#include"AnimowaneAssety.h"

class Bohater : public AnimowaneAssety
{
private :
    sf::Vector2f cel_;
public :
    Bohater(int a,int b,const sf::Texture &tex1);
    int hp;
    bool resault();
    void UstawCel(const sf::Vector2f& cel);

    void PodazajDoCelu();


};

#endif // BOHATER_H
#pragma once
