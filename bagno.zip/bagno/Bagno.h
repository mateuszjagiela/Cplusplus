#ifndef BAGNO_H
#define BAGNO_H
#include <iostream>
#include <SFML/Window.hpp>
#include <SFML/Graphics.hpp>
#include"AnimowaneAssety.h"

class Bagno : public AnimowaneAssety
{
public :
    Bagno(int a,int b,const sf::Texture &tex);




};



#endif // BAGNO_H
#pragma once
