#include <iostream>
#include <SFML/Window.hpp>
#include <SFML/Graphics.hpp>
#include "Potwor.h"

Potwor :: Potwor(int a,int b,const sf::Texture &tex3)
{
    srand(time(NULL));
    setTexture(tex3);
    setPosition(a,b);
    predkosc_x=0;
    predkosc_y=rand()&400-200;
}










#pragma once
