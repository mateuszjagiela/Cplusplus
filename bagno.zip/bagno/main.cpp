#include <iostream>
#include <SFML/Window.hpp>
#include <SFML/Graphics.hpp>
#include"AnimowaneAssety.h"
#include"Bagno.h"
#include"Bohater.h"
#include"Potwor.h"
#include"AnimowaneAssety.cpp"
#include"Bagno.cpp"
#include"Bohater.cpp"
#include"Potwor.cpp"


int main()
{
    sf::RenderWindow window(sf::VideoMode(800, 600), "Bagno XD");
    sf::Clock zegar;

    srand(time(NULL));

    sf::Texture tex;
    tex.loadFromFile("./../bagno/bagno.png");
    sf::Texture tex2;
    tex2.loadFromFile("./../bagno/guy.png");
    sf::Texture tex3;
    tex3.loadFromFile("./../bagno/potwor.png");
    std::vector<Bagno> bagna;
    std::vector<Potwor> potwory;

    for(int i=0;i<5;i++)
    {
        int los=rand()%100+600;
        //int czy = rand()%2;
        int pos_x;
        int pos_y;
        int los2=rand()%500;
        //int czy2=rand()%2;
        pos_x=los;
        pos_y=los2;
        Potwor potwor(pos_x,pos_y,tex3);
        potwory.emplace_back(potwor);
        std::cout << potwory.size() << std::endl;
    }

    for(int i=0;i<=potwory.size();i++)
    {
        if((potwory[i].getPosition().x==potwory[i+1].getPosition().x)&&(potwory[i].getPosition().y==potwory[i+1].getPosition().y))
        {
            //std::cout << "Nie bangla";
            potwory.erase(potwory.begin()+(i+1));

            do
            {
            int los=rand()%100+600;
            int pos_x;
            int pos_y;
            int los2=rand()%500;
            pos_x=los;
            pos_y=los2;
            Potwor potwor(pos_x,pos_y,tex3);
            potwory.emplace_back(potwor);
            }while(potwory.size()==5);

        }
        //else std::cout << "Bangla" << std::endl;
    }


    for(int i=0;i<10;i++)
    {
        int los=rand()%100+600;
        //int czy = rand()%2;
        int pos_x;
        int pos_y;
        int los2=rand()%500;
        //int czy2=rand()%2;
        pos_x=los;
        pos_y=los2;
        Bagno bagno(pos_x,pos_y,tex);
        bagna.emplace_back(bagno);
        std::cout << bagna.size() << std::endl;
    }


    for(int i=0;i<=bagna.size();i++)
    {
        if((bagna[i].getPosition().x==bagna[i+1].getPosition().x)&&(bagna[i].getPosition().y==bagna[i+1].getPosition().y))
        {
            //std::cout << "Nie bangla";
            potwory.erase(potwory.begin()+(i+1));
            int los=rand()%100+600;
            int pos_x;
            int pos_y;
            int los2=rand()%500;
            pos_x=los;
            pos_y=los2;
            Bagno bagno(pos_x,pos_y,tex3);
            bagna.emplace_back(bagno);

        }
        //else std::cout << "Bangla" << std::endl;
    }






    Bohater bohater(5,(window.getSize().y-45),tex2);
    std::cout << bohater.getGlobalBounds().height;

    bool bohater_ok=true;


    while(window.isOpen()&& bohater_ok==true)
    {

        sf::Time elapsed = zegar.restart();




        for(int i=0;i<=bagna.size();i++)
        {
            bagna[i].CiaglaAnimacja(elapsed);
        }

        for(int i=0;i<potwory.size();i++)
        {
            potwory[i].CiaglaAnimacja(elapsed);
        }

        sf::Event event;
        while (window.pollEvent(event))
        {

            if (event.type == sf::Event::Closed)
                window.close();

            if(event.type==sf::Event::KeyPressed)
            {
                if(sf::Keyboard::isKeyPressed(sf::Keyboard::B))
                {
                    bohater.setPosition(5,window.getSize().y-45);
                    bohater.predkosc_x=0;
                    bohater.predkosc_y=0;
                }
            }

            if (event.type == sf::Event::MouseButtonPressed)
                        {
                            if (sf::Mouse::isButtonPressed(sf::Mouse::Left))
                            {
                                sf::Vector2f mouse_position = window.mapPixelToCoords(sf::Mouse::getPosition(window));
                                bohater.UstawCel(mouse_position);
                            }

                        }

        }

        bohater.PodazajDoCelu();



        srand(time(NULL));
        for(int i=0;i<=potwory.size();i++)
        {
            if(bohater.getGlobalBounds().intersects(potwory[i].getGlobalBounds()))
            {
                std::cout << "Przeciecie z potworem" << std::endl;
                bohater.hp--;
                potwory.erase(potwory.begin()+i);
                int los=rand()%100+600;
                int pos_x;
                int pos_y;
                int los2=rand()%500;
                pos_x=los;
                pos_y=los2;
                Potwor potwor(pos_x,pos_y,tex3);
                potwory.emplace_back(potwor);
            }

        }

        for(int i=0;i<=bagna.size();i++)
        {
            if(bohater.getGlobalBounds().intersects(bagna[i].getGlobalBounds()))
            {
                std::cout << "Przeciecie z potworem" << std::endl;
                bohater.hp--;
                bagna.erase(bagna.begin()+i);
                int los=rand()%100+600;
                int pos_x;
                int pos_y;
                int los2=rand()%500;
                pos_x=los;
                pos_y=los2;
                Bagno bagno(pos_x,pos_y,tex3);
                bagna.emplace_back(bagno);
            }

        }





        window.clear(sf::Color::Black);

        for(const auto &p:potwory)
        {
            window.draw(p);
        }

        for(const auto &b : bagna)
        {
            window.draw(b);
        }


        window.draw(bohater);
        window.display();

        bohater_ok=!bohater.resault();

    }


    return 0;
}
