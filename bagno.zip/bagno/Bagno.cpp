#include <iostream>
#include <SFML/Window.hpp>
#include <SFML/Graphics.hpp>
#include "Bagno.h"

Bagno :: Bagno(int a,int b,const sf::Texture &tex)
{
    setTexture(tex);
    setPosition(a,b);
    setScale(1,1);
    predkosc_x=rand()%100-50;
    predkosc_y=0;
}



#pragma once
