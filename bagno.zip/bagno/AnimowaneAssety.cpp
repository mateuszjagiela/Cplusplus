#include <iostream>
#include <SFML/Window.hpp>
#include <SFML/Graphics.hpp>
#include"AnimowaneAssety.h"

void AnimowaneAssety :: CiaglaAnimacja(const sf::Time &elapsed)
{
    move(predkosc_x*elapsed.asSeconds(),predkosc_y*elapsed.asSeconds());
    if(getGlobalBounds().top<=0)
    {
        setPosition(getPosition().x,600-getGlobalBounds().height);
    }
    else if(getGlobalBounds().top+getGlobalBounds().height>=600)
    {
        setPosition(getPosition().x,0);
    }
    else if(getGlobalBounds().left<=0)
    {
        setPosition(800-getGlobalBounds().width,getPosition().y);
    }
    else if((getGlobalBounds().left+getGlobalBounds().width)>=800)
    {
        setPosition(0,getPosition().y);
    }
}



#pragma once
