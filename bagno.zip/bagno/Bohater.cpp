#include <iostream>
#include <SFML/Window.hpp>
#include <SFML/Graphics.hpp>
#include "Bohater.h"

Bohater::Bohater(int a,int b,const sf::Texture &tex2)
{
    setTexture(tex2);
    setPosition(a,b);
    predkosc_x=0;
    predkosc_y=0;
    hp=3;
   sf::Vector2i obrys((getGlobalBounds().left+getGlobalBounds().width)/2,(getGlobalBounds().top+getGlobalBounds().height)/2);
}


bool Bohater :: resault() //sprawdzic czy tu nie ma problemu
{
    bool resault=false;

    if(hp<=0)
    {
        std::cout << "Przegrana" << std::endl;
        resault = true;
    }
    return resault;
}

void Bohater::UstawCel(const sf::Vector2f& cel)
{
    cel_=cel;
    std::cout << cel.x << std::endl << cel.y << std::endl;
}

void Bohater :: PodazajDoCelu()
{
    //move(0,0);
    //setPosition(5,555);

        if(getPosition().x < cel_.x)
        {
            move((cel_.x-getPosition().x)/1000,0);
        }

        else if(getPosition().x>cel_.x)
        {
            move((cel_.x-getPosition().x)/1000,0);
        }

        if(getPosition().y<cel_.y)
        {
            move(0,(cel_.y-getPosition().y)/1000);
        }
       else if(getPosition().y>cel_.y)
        {
            move(0,((cel_.y-getPosition().y)/1000));
        }



}

#pragma once
